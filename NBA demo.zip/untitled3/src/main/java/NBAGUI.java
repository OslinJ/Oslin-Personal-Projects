import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;

public class NBAGUI extends JFrame {
    private final JTable table;
    private final DefaultTableModel tableModel;
    private final NBAApiClient apiClient;
    private final JLabel statusLabel;
    private final JDateChooser dateChooser;
    private final JButton refreshButton;

    public NBAGUI() {
        setTitle("NBA Game Scores");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Initialize API client
        apiClient = new NBAApiClient();

        // Create control panel (top)
        JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        // Add date picker
        JLabel dateLabel = new JLabel("Game Date:");
        controlPanel.add(dateLabel);

        dateChooser = new JDateChooser();
        dateChooser.setDate(java.util.Date.from(LocalDate.now().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant()));
        dateChooser.setPreferredSize(new Dimension(120, 25));
        controlPanel.add(dateChooser);

        // Add refresh button
        refreshButton = new JButton("Refresh Games");
        refreshButton.addActionListener(this::refreshData);
        controlPanel.add(refreshButton);

        add(controlPanel, BorderLayout.NORTH);

        // Set up table
        String[] columnNames = {"Home Team", "Away Team", "Home Score", "Away Score", "Game Status"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table read-only
            }
        };

        table = new JTable(tableModel);
        table.getTableHeader().setReorderingAllowed(false);
        table.setRowHeight(25);
        table.setFillsViewportHeight(true);

        // Add table with scroll pane
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Status bar
        statusLabel = new JLabel("Ready");
        add(statusLabel, BorderLayout.SOUTH);

        // Load initial data
        loadData();
    }

    private void refreshData(ActionEvent event) {
        refreshButton.setEnabled(false);
        statusLabel.setText("Refreshing data...");

        SwingWorker<Void, Void> worker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() {
                loadData();
                return null;
            }

            @Override
            protected void done() {
                refreshButton.setEnabled(true);
                statusLabel.setText("Data refreshed at " +
                                    LocalDate.now().atStartOfDay().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            }
        };
        worker.execute();
    }

    private void loadData() {
        try {
            // Clear existing table data
            tableModel.setRowCount(0);

            // Get selected date from date picker
            java.util.Date selectedDate = dateChooser.getDate();
            LocalDate gameDate = selectedDate.toInstant()
                    .atZone(java.time.ZoneId.systemDefault())
                    .toLocalDate();

            List<DatabaseManager.Game> savedGames = DatabaseManager.fetchGamesFromDatabase();
            for (DatabaseManager.Game game : savedGames) {
                tableModel.addRow(new Object[]{
                        game.getHomeTeam(),
                        game.getAwayTeam(),
                        game.getHomeScore(),
                        game.getAwayScore(),
                        "Final (DB)"
                });
            }

            JsonNode apiResponse = apiClient.fetchGameData(gameDate);
            if (apiResponse != null) {
                JsonNode games = apiResponse.path("resultSets").get(0).path("rowSet");

                for (JsonNode game : games) {
                    String homeTeam = game.get(6).asText();
                    String awayTeam = game.get(7).asText();
                    int homeScore = game.get(21).asInt();
                    int awayScore = game.get(22).asInt();
                    String gameStatus = game.get(4).asText();

                    tableModel.addRow(new Object[]{
                            homeTeam,
                            awayTeam,
                            homeScore,
                            awayScore,
                            gameStatus
                    });

                    if ("Final".equals(gameStatus)) {
                        DatabaseManager.insertGame(homeTeam, awayTeam, homeScore, awayScore);
                    }
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Error loading data: " + e.getMessage(),
                    "Data Error",
                    JOptionPane.ERROR_MESSAGE);
            statusLabel.setText("Error loading data");
        }
    }

    private static class JDateChooser extends JPanel {
        private final JTextField dateField;
        private java.util.Date date;

        public JDateChooser() {
            setLayout(new BorderLayout());
            dateField = new JTextField(10);
            JButton calendarButton = new JButton("...");
            calendarButton.setPreferredSize(new Dimension(20, 20));

            add(dateField, BorderLayout.CENTER);
            add(calendarButton, BorderLayout.EAST);


            calendarButton.addActionListener(e -> {

                String input = JOptionPane.showInputDialog(this, "Enter date (YYYY-MM-DD):",
                        dateField.getText());
                if (input != null && !input.isEmpty()) {
                    try {
                        setDate(java.util.Date.from(
                                LocalDate.parse(input).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant()));
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, "Invalid date format");
                    }
                }
            });
        }

        public void setDate(java.util.Date date) {
            this.date = date;
            dateField.setText(DateTimeFormatter.ISO_DATE.format(
                    date.toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDate()));
        }

        public java.util.Date getDate() {
            return date;
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> new NBAGUI().setVisible(true));
    }
}