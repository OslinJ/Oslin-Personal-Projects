import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Manages database operations for NBA game statistics
 */
public class DatabaseManager {
    private static final Logger LOGGER = Logger.getLogger(DatabaseManager.class.getName());

    // Database configuration
    private static final String URL = "jdbc:mysql://localhost:3306/nba_stats";
    private static final String USER = "root";
    private static final String PASSWORD = "Dragonball5";


    public static Connection connect() throws SQLException {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Failed to connect to database", e);
            throw e;
        }
    }

    /**
     * Updates database schema to add new columns if needed
     */
    public static void upgradeSchema() {
        // First check if game_date column exists
        boolean hasGameDateColumn = false;

        try (Connection conn = connect()) {
            DatabaseMetaData meta = conn.getMetaData();
            ResultSet columns = meta.getColumns(null, null, "games", "game_date");
            hasGameDateColumn = columns.next(); // True if column exists
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "Error checking schema", e);
        }

        // Add game_date column if it doesn't exist
        if (!hasGameDateColumn) {
            try (Connection conn = connect();
                 Statement stmt = conn.createStatement()) {
                stmt.execute("ALTER TABLE games ADD COLUMN game_date DATE DEFAULT CURRENT_DATE");
                LOGGER.info("Added game_date column to games table");
            } catch (SQLException e) {
                LOGGER.log(Level.SEVERE, "Error upgrading schema", e);
            }
        }
    }

    /**
     * Creates the games table if it doesn't exist
     */
    public static void createTable() {
        String sql = "CREATE TABLE IF NOT EXISTS games ("
                     + "id INT AUTO_INCREMENT PRIMARY KEY,"
                     + "home_team VARCHAR(50) NOT NULL,"
                     + "away_team VARCHAR(50) NOT NULL,"
                     + "home_score INT NOT NULL,"
                     + "away_score INT NOT NULL"
                     + ");";

        try (Connection conn = connect();
             Statement stmt = conn.createStatement()) {
            stmt.execute(sql);
            LOGGER.info("Games table created or verified");

            // After creating table, check if we need to upgrade schema
            upgradeSchema();
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error creating games table", e);
        }
    }

    /**
     * Inserts a game record into the database
     */
    public static boolean insertGame(String home, String away, int homeScore, int awayScore) {
        if (home == null || away == null || home.isEmpty() || away.isEmpty() || homeScore < 0 || awayScore < 0) {
            LOGGER.warning("Invalid game data provided");
            return false;
        }

        String sql;
        boolean useGameDate = false;

        try (Connection conn = connect()) {
            DatabaseMetaData meta = conn.getMetaData();
            ResultSet columns = meta.getColumns(null, null, "games", "game_date");
            useGameDate = columns.next(); // True if column exists
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "Error checking schema", e);
        }

        if (useGameDate) {
            sql = "INSERT INTO games (home_team, away_team, home_score, away_score, game_date) VALUES (?, ?, ?, ?, CURRENT_DATE)";
        } else {
            sql = "INSERT INTO games (home_team, away_team, home_score, away_score) VALUES (?, ?, ?, ?)";
        }

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, home);
            pstmt.setString(2, away);
            pstmt.setInt(3, homeScore);
            pstmt.setInt(4, awayScore);

            int rowsAffected = pstmt.executeUpdate();
            LOGGER.info("Game inserted: " + home + " vs " + away + ", rows affected: " + rowsAffected);
            return rowsAffected > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error inserting game: " + home + " vs " + away, e);
            return false;
        }
    }

    /**
     * Retrieves all games from the database
     */
    public static List<Game> fetchGamesFromDatabase() {
        List<Game> games = new ArrayList<>();

        String sql;
        boolean hasGameDate = false;

        try (Connection conn = connect()) {
            DatabaseMetaData meta = conn.getMetaData();
            ResultSet columns = meta.getColumns(null, null, "games", "game_date");
            hasGameDate = columns.next(); // True if column exists
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "Error checking schema", e);
        }

        if (hasGameDate) {
            sql = "SELECT home_team, away_team, home_score, away_score, game_date FROM games";
        } else {
            sql = "SELECT home_team, away_team, home_score, away_score FROM games";
        }

        try (Connection conn = connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Game game;
                if (hasGameDate) {
                    game = new Game(
                            rs.getString("home_team"),
                            rs.getString("away_team"),
                            rs.getInt("home_score"),
                            rs.getInt("away_score"),
                            rs.getDate("game_date").toLocalDate()
                    );
                } else {
                    game = new Game(
                            rs.getString("home_team"),
                            rs.getString("away_team"),
                            rs.getInt("home_score"),
                            rs.getInt("away_score"),
                            LocalDate.now() // Default to current date
                    );
                }
                games.add(game);
            }

            LOGGER.info("Retrieved " + games.size() + " games from database");
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error fetching games from database", e);
        }

        return games;
    }

    public static class Game {
        private final String homeTeam;
        private final String awayTeam;
        private final int homeScore;
        private final int awayScore;
        private final LocalDate gameDate;

        public Game(String homeTeam, String awayTeam, int homeScore, int awayScore, LocalDate gameDate) {
            this.homeTeam = homeTeam;
            this.awayTeam = awayTeam;
            this.homeScore = homeScore;
            this.awayScore = awayScore;
            this.gameDate = gameDate != null ? gameDate : LocalDate.now();
        }

        public String getHomeTeam() { return homeTeam; }
        public String getAwayTeam() { return awayTeam; }
        public int getHomeScore() { return homeScore; }
        public int getAwayScore() { return awayScore; }
        public LocalDate getGameDate() { return gameDate; }

        @Override
        public String toString() {
            return homeTeam + " vs " + awayTeam + " | Score: " + homeScore + " - " + awayScore;
        }
    }
}