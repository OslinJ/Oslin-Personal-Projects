import java.util.Scanner;

/**
 * This program converts an infix notation equation to postfix notation.
 * It takes user input, processes the expression using a stack,
 * and prints the corresponding postfix notation.
 */
public class Main {
    public static void main(String[] args) {
        infixToPostfix();
    }

    /**
     * Converts an infix notation equation to postfix notation.
     * The method reads an equation from user input, processes it using a stack,
     * and prints the postfix equivalent.
     */
    public static void infixToPostfix() {
        Scanner scan  = new Scanner(System.in);
        Stacking<Character> stack = new Stacking<>();
        StringBuilder builder = new StringBuilder();

        System.out.println("Enter the infix notation equation:");
        String input = scan.nextLine();

        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);

            // If character is an operand, add it to the output
            if (Character.isLetterOrDigit(ch)) {
                builder.append(ch);
            }

            // If character is '(', push to stack
            if (ch == '(') {
                stack.push(ch);
            }
            // If character is ')', pop from stack until '(' is found
            else if (ch == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    builder.append(stack.pop());
                }
                stack.pop(); // Remove '(' from stack
            }
            // If character is an operator, process operator precedence
            else if (ch == '+' || ch == '-' || ch == '*' || ch == '/') {
                while (!stack.isEmpty() && operatorPrecedence(stack.peek()) >= operatorPrecedence(ch)) {
                    builder.append(stack.pop());
                }
                stack.push(ch);
            }
        }

        // Pop all remaining operators from stack
        while (!stack.isEmpty()) {
            builder.append(stack.pop());
        }

        // Output the postfix expression
        System.out.println(builder);
    }

    /**
     * Determines the precedence of an operator.
     * Higher precedence value means higher priority in expression evaluation.
     *
     * @param operator The operator character.
     * @return The precedence value (higher value means higher precedence).
     */
    public static int operatorPrecedence(char operator) {
        return switch (operator) {
            case '+', '-' -> 1;
            case '*', '/' -> 2;
            default -> -1;
        };
    }
}
