import java.util.EmptyStackException;

public class Stacking<T>{
    private int top;
    T[] stacks;

    public Stacking(){
        this(5);
   }
   public Stacking(int size){
        top = 0;
        stacks = (T[]) new Object[size];
   }
   public void push(T data){
        if(top == stacks.length){
            T[] temp = (T[]) new Object[stacks.length*2];
            for(int i = 0 ; i < stacks.length; i++){
                temp[i] = stacks[i];
                stacks = temp;
            }
        }
        stacks[top++] = data;
   }
   public T pop(){
        if(top <= 0){
            throw new EmptyStackException();
        }
        T data = stacks[top - 1];
        top--;
        return data;
   }
   public char peek(){
        if(top <= 0){
            throw new EmptyStackException();
        }
        return (char) stacks[top - 1];
   }
   public void print(){
        for(int i = 0; i < top; i++){
            System.out.print(stacks[i] + ", ");
        }
       System.out.println();
   }

    public boolean isEmpty() {
        return top == 0;
    }
}
