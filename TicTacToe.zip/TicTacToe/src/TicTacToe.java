
import java.util.Scanner;

public class TicTacToe {
    private char[][] boardLayout;
    private boolean gameOver;
    private static final char EMPTY = '-';
    private static final char PLAYER = 'X';
    private static final char CPU = 'O';

    public TicTacToe() {
        System.out.println("Let's play Tic-Tac-Toe!");
        boardLayout = new char[][]{{'-', '-', '-'},
                {'-', '-', '-'},
                {'-', '-', '-'}};

        gameOver = false;
        printBoard();
        while (!gameOver) {
            playerMove();
            if (checkWin(PLAYER)) {
                printBoard();
                System.out.println("Player wins!");
                break;
            }
            if (isBoardFull()) {
                printBoard();
                System.out.println("It's a draw!");
                break;
            }

            cpuMovement();
            if (checkWin(CPU)) {
                printBoard();
                System.out.println("CPU wins!");
                break;
            }
            if (isBoardFull()) {
                printBoard();
                System.out.println("It's a draw!");
                break;
            }

            printBoard();
        }
    }
    public void printBoard() {
        for (char[] row : boardLayout) {
            for (char cell : row) {
                System.out.print(cell + " ");
            }
            System.out.println();
        }
    }
    public void playerMove() {
        Scanner scanner = new Scanner(System.in);
        int playerMovement;
        while (true) {
            System.out.println("Enter your move (Select a number 1-9): ");
            playerMovement = scanner.nextInt();
            playerMovement--; // Adjust for 0-based index
            if (playerMovement < 0 || playerMovement >= 9) {
                System.out.println("Invalid input. Please select a number between 1 and 9.");
            } else {
                int row = playerMovement / 3;
                int col = playerMovement % 3;
                if (boardLayout[row][col] == EMPTY) {
                    boardLayout[row][col] = PLAYER;
                    break;
                } else {
                    System.out.println("The cell is already occupied. Try another move.");
                }
            }
        }
    }
    public void cpuMovement() {
        int cpuMovement;
        while (true) {
            cpuMovement = (int) (Math.random() * 9);
            int row = cpuMovement / 3;
            int col = cpuMovement % 3;
            if (boardLayout[row][col] == EMPTY) {
                boardLayout[row][col] = CPU;
                break;
            }
        }
    }
    public boolean isBoardFull() {
        for (char[] row : boardLayout) {
            for (char cell : row) {
                if (cell == EMPTY) {
                    return false;
                }
            }
        }
        return true;
    }
    public boolean checkWin(char player) {
        // Check rows, columns, and diagonals
        for (int i = 0; i < 3; i++) {
            if (boardLayout[i][0] == player && boardLayout[i][1] == player && boardLayout[i][2] == player) {
                return true;
            }
            if (boardLayout[0][i] == player && boardLayout[1][i] == player && boardLayout[2][i] == player) {
                return true;
            }
        }
        if (boardLayout[0][0] == player && boardLayout[1][1] == player && boardLayout[2][2] == player) {
            return true;
        }
        return boardLayout[0][2] == player && boardLayout[1][1] == player && boardLayout[2][0] == player;
    }
    public static void main(String[] args) {
        new TicTacToe();
    }
}