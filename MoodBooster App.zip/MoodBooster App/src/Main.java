public class Main {
    public static void main(String[] args) {
        try {
            // Get weather info
            Weather weather = WeatherService.getWeather("Toronto");
            System.out.println("🌤️ Today's Weather:\n" + weather);

            // Get joke
            String joke = JokeService.getJoke();
            System.out.println("\n😂 Here's a joke to brighten your day:\n" + joke);

        } catch (Exception e) {
            System.out.println("Something went wrong: " + e.getMessage());
        }
    }
}
