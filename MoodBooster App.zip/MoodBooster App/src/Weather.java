public class Weather {
    public Main main;
    public WeatherCondition[] weather;
    public String name;

    public class Main{
        public double temp;
    }

    public class WeatherCondition{
        public String main;
        public String description;
    }

    public String toString(){
        return "City: " + name+
               "\nTemperature: " + main.temp + "°C" +
               "\nCondition: " + weather[0].main + " (" + weather[0].description + ")";
    }
}
