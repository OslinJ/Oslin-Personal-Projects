/**
 * Sudoku Solver using a backtracking algorithm.
 * The program attempts to solve a 9x9 Sudoku board by filling in empty cells
 * while adhering to the Sudoku rules.
 */
public class Main {

    private static final int GRID_SIZE = 9;

    /**
     * Main method that initializes a Sudoku board, prints it, solves it,
     * and prints the solved board.
     */
    public static void main(String[] args) {
        int[][] board = {
                {0, 0, 0, 8, 3, 0, 1, 0, 7},
                {0, 0, 0, 0, 0, 0, 6, 0, 0},
                {3, 5, 6, 7, 1, 0, 0, 0, 0},
                {0, 0, 2, 1, 7, 8, 3, 4, 9},
                {7, 4, 0, 9, 6, 0, 8, 1, 0},
                {0, 8, 0, 2, 4, 0, 7, 6, 5},
                {8, 2, 0, 0, 9, 0, 0, 3, 1},
                {0, 0, 0, 5, 8, 0, 2, 0, 0},
                {0, 1, 5, 0, 2, 0, 0, 0, 6},
        };

        printBoard(board);
        if (solveBoard(board)) {
            System.out.println("Solved Successfully!");
        } else {
            System.out.println("Unsolvable board...");
        }
        printBoard(board);
    }

    /**
     * Prints the Sudoku board in a formatted manner.
     *
     * @param board The 2D array representing the Sudoku board.
     */
    private static void printBoard(int[][] board) {
        for (int row = 0; row < GRID_SIZE; row++) {
            if (row % 3 == 0 && row != 0) {
                System.out.println("-------------------");
            }
            for (int col = 0; col < GRID_SIZE; col++) {
                if (col % 3 == 0 && col != 0) {
                    System.out.print("|");
                }
                System.out.print(board[row][col] + " ");
            }
            System.out.println();
        }
    }

    /**
     * Checks if a given number is already present in the specified row.
     *
     * @param board  The Sudoku board.
     * @param number The number to check.
     * @param row    The row to check.
     * @return true if the number is in the row, false otherwise.
     */
    private static boolean isNumberInRow(int[][] board, int number, int row) {
        for (int i = 0; i < GRID_SIZE; i++) {
            if (board[row][i] == number) {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if a given number is already present in the specified column.
     *
     * @param board  The Sudoku board.
     * @param number The number to check.
     * @param column The column to check.
     * @return true if the number is in the column, false otherwise.
     */
    private static boolean isNumberInColumn(int[][] board, int number, int column) {
        for (int i = 0; i < GRID_SIZE; i++) {
            if (board[i][column] == number) {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if a given number is already present in the 3x3 subgrid
     * containing the specified cell.
     *
     * @param board  The Sudoku board.
     * @param number The number to check.
     * @param row    The row index of the cell.
     * @param column The column index of the cell.
     * @return true if the number is in the subgrid, false otherwise.
     */
    private static boolean isNumberInBox(int[][] board, int number, int row, int column) {
        int localBoxRow = row - row % 3;
        int localBoxColumn = column - column % 3;

        for (int i = localBoxRow; i < localBoxRow + 3; i++) {
            for (int j = localBoxColumn; j < localBoxColumn + 3; j++) {
                if (board[i][j] == number) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Checks if placing a given number in the specified cell is a valid move
     * according to Sudoku rules.
     *
     * @param board  The Sudoku board.
     * @param number The number to place.
     * @param row    The row index of the cell.
     * @param column The column index of the cell.
     * @return true if the placement is valid, false otherwise.
     */
    private static boolean isValidPlacement(int[][] board, int number, int row, int column) {
        return !isNumberInRow(board, number, row) &&
                !isNumberInColumn(board, number, column) &&
                !isNumberInBox(board, number, row, column);
    }

    /**
     * Solves the Sudoku board using a backtracking algorithm.
     *
     * @param board The 2D array representing the Sudoku board.
     * @return true if the board is successfully solved, false if it is unsolvable.
     */
    private static boolean solveBoard(int[][] board) {
        for (int row = 0; row < GRID_SIZE; row++) {
            for (int col = 0; col < GRID_SIZE; col++) {
                if (board[row][col] == 0) {
                    for (int numberToTry = 1; numberToTry <= GRID_SIZE; numberToTry++) {
                        if (isValidPlacement(board, numberToTry, row, col)) {
                            board[row][col] = numberToTry;

                            if (solveBoard(board)) {
                                return true;
                            } else {
                                board[row][col] = 0;
                            }
                        }
                    }
                    return false;
                }
            }
        }
        return true;
    }
}
