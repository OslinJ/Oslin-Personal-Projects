import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Interface representing an order of food items.
 */
public interface Order {
    /**
     * Adds a food item to the order.
     *
     * @param item the FoodItem to add
     * @throws IllegalArgumentException if the item is null, or its name is invalid
     */
    void addItem(FoodItem item);

    /**
     * Calculates the total cost of the order.
     *
     * @return the total cost of all food items in the order
     * @throws IllegalStateException if there are no items in the order
     */
    double calculateTotal();

    /**
     * Displays the details of the order, including the description of each item.
     *
     * @throws IllegalArgumentException if there are no items in the order
     */
    void displayOrderDetail();
}

/**
 * Implementation of the Order interface, representing a list of food items.
 */
class FoodOrder implements Order {
    private ArrayList<FoodItem> items = new ArrayList<>();

    /**
     * Returns an unmodifiable view of the items in the order.
     *
     * @return an unmodifiable list of FoodItems
     */
    public List<FoodItem> getItems() {
        return Collections.unmodifiableList(items);
    }

    /**
     * Adds a food item to the order.
     *
     * @param item the FoodItem to add
     * @throws IllegalArgumentException if the item is null or its name is invalid
     */
    @Override
    public void addItem(FoodItem item) {
        if (item == null) {
            throw new IllegalArgumentException("Food item cannot be null");
        }
        if (item.getName() == null || item.getName().isEmpty()) {
            throw new IllegalArgumentException("Item name cannot be null or empty");
        }
        for (FoodItem foodItem : items) {
            if (foodItem.getName().equals(item.getName())) {
                throw new IllegalArgumentException("Item already exists in the order");
            }
            System.out.println(foodItem.getName());
        }
        items.add(item);
    }

    /**
     * Calculates the total cost of all items in the order.
     *
     * @return the total cost of all items in the order
     * @throws IllegalStateException if there are no items in the order
     */
    @Override
    public double calculateTotal() {
        if (items.isEmpty()) {
            throw new IllegalStateException("No items in the order.");
        }
        double total = 0;
        for (FoodItem foodItem : items) {
            total += foodItem.getPrice();
        }
        System.out.println("Total cost: $" + total);
        return total;
    }

    /**
     * Displays the description of each item in the order.
     *
     * @throws IllegalArgumentException if there are no items in the order
     */
    @Override
    public void displayOrderDetail() {
        if (items.isEmpty()) {
            throw new IllegalArgumentException("No items in the order to display.");
        }
        for (FoodItem foodItem : items) {
            System.out.println(foodItem.getDescription());
        }
    }
}

/**
 * Driver class to test the functionality of the food ordering system.
 */
class OnlineFoodOrderSystem {
    public static void main(String[] args) {
        System.out.println("Order Details:");
        Order order = new FoodOrder();
        order.addItem(new Pizza());
        order.addItem(new Burger());
        order.addItem(new Salad());
        order.calculateTotal();

        System.out.println("\nFood description:");
        order.displayOrderDetail();
    }
}
