/**
 * Rectangle class that implements the Shape interface and represents a rectangle.
 */
public class Rectangle implements Shape {
    private int height;
    private int width;

    /**
     * Constructor that initializes the Rectangle with a given height and width.
     * @param height the height of the rectangle.
     * @param width the width of the rectangle.
     */
    public Rectangle(int height, int width) {
        this.height = height;
        this.width = width;
    }

    /**
     * Sets a new height for the rectangle.
     * @param height the new height of the rectangle.
     */
    public void setHeight(int height) {
        if (height < 0) {
            throw new IllegalArgumentException("Height cannot be negative");
        }
        this.height = height;
    }

    /**
     * Sets a new width for the rectangle.
     * @param width the new width of the rectangle.
     */
    public void setWidth(int width) {
        if (width < 0) {
            throw new IllegalArgumentException("Width cannot be negative");
        }
        this.width = width;
    }

    /**
     * Returns the height of the rectangle.
     * @return the height of the rectangle.
     */
    public int getHeight() {
        return height;
    }

    /**
     * Returns the width of the rectangle.
     * @return the width of the rectangle.
     */
    public int getWidth() {
        return width;
    }

    /**
     * Calculates and returns the area of the rectangle.
     * @return the area of the rectangle.
     */
    @Override
    public double area() {
        return getHeight() * getWidth();
    }
}