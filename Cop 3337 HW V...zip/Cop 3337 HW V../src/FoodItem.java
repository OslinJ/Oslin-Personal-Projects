/**
 * The FoodItem interface defines the contract for food items.
 * It includes methods to retrieve the name, price, and description of the food item.
 */
public interface FoodItem {
    /**
     * Returns the name of the food item.
     * @return the name of the food item.
     */
    String getName();

    /**
     * Returns the price of the food item.
     * @return the price of the food item.
     */
    double getPrice();

    /**
     * Returns the description of the food item.
     * @return the description of the food item.
     */
    String getDescription();
}

/**
 * Abstract class AbstractFoodItem provides a base implementation of the FoodItem interface.
 * It includes a helper method to format the description for all food items.
 */
abstract class AbstractFoodItem implements FoodItem {
    /**
     * Helper method to format the description of the food item.
     * @param itemDetails specific details of the food item.
     * @return the formatted description including price.
     */
    protected String formatDescription(String itemDetails) {
        return itemDetails + " price = $" + getPrice();
    }
}

/**
 * The Pizza class represents a specific food item (Pizza) and provides its details.
 * It extends AbstractFoodItem and implements the methods defined in FoodItem.
 */
class Pizza extends AbstractFoodItem {
    /**
     * Sets the name of the pizza. Throws an exception if the name is null or empty.
     * @param name the name of the pizza.
     */
    public void setName(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Name cannot be null or empty");
        }
    }

    /**
     * Returns the name of the pizza with its price.
     * @return the name of the pizza.
     */
    @Override
    public String getName() {
        return "Pizza(Large):$" + getPrice();
    }

    /**
     * Returns the price of the pizza.
     * @return the price of the pizza.
     */
    @Override
    public double getPrice() {
        return 12.99;
    }

    /**
     * Returns the description of the pizza.
     * @return the description of the pizza.
     */
    @Override
    public String getDescription() {
        return formatDescription("1x Large Pizza with one topping (Pepperoni)");
    }
}

/**
 * The Burger class represents a specific food item (Burger) and provides its details.
 * It extends AbstractFoodItem and implements the methods defined in FoodItem.
 */
class Burger extends AbstractFoodItem {
    /**
     * Returns the name of the burger with its price.
     * @return the name of the burger.
     */
    @Override
    public String getName() {
        return "Burger Combo:$" + getPrice();
    }

    /**
     * Returns the price of the burger.
     * @return the price of the burger.
     */
    @Override
    public double getPrice() {
        return 9.99;
    }

    /**
     * Returns the description of the burger.
     * @return the description of the burger.
     */
    @Override
    public String getDescription() {
        return formatDescription("1x Burger combo includes Fries and drink (Sprite)");
    }
}

/**
 * The Salad class represents a specific food item (Salad) and provides its details.
 * It extends AbstractFoodItem and implements the methods defined in FoodItem.
 */
class Salad extends AbstractFoodItem {
    /**
     * Returns the name of the salad with its price.
     * @return the name of the salad.
     */
    @Override
    public String getName() {
        return "Salad(Caesar):$" + getPrice();
    }

    /**
     * Returns the price of the salad.
     * @return the price of the salad.
     */
    @Override
    public double getPrice() {
        return 6.49;
    }

    /**
     * Returns the description of the salad.
     * @return the description of the salad.
     */
    @Override
    public String getDescription() {
        return formatDescription("1x Caesar Salad");
    }
}
