/**
 * Circle class that implements the Shape interface and represents a circle.
 */
public class Circle implements Shape {

    private double radius;
    /**
     * Constructor that initializes the Circle with a given radius.
     * @param radius the radius of the circle.
     */
    public Circle(double radius) {
        this.radius = radius;
    }

    /**
     * Returns the radius of the circle.
     * @return the radius of the circle.
     */
    public double getRadius() {
        return radius;
    }

    /**
     * Sets a new radius for the circle.
     * @param radius the new radius of the circle.
     */
    public void setRadius(double radius) {
        if (radius < 0) {
            throw new IllegalArgumentException("Radius cannot be negative");
        }
        this.radius = radius;
    }

    /**
     * Calculates and returns the area of the circle.
     * @return the area of the circle.
     */
    @Override
    public double area() {
        return Math.PI * (getRadius() * getRadius());
    }
}
