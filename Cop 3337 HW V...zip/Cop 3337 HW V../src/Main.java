/**
 * Shape interface that defines a method to calculate the area of a shape.
 */
interface Shape {
    /**
     * Calculates and returns the area of the shape.
     * @return the area of the shape as a double.
     */
    public double area();
}
/**
 * Main class to demonstrate the use of Shape interface and its implementations.
 */
public class Main {
    /**
     *Creates instances of Circle and Rectangle,
     * and calls the ShowArea method to display the area of each shape.
     */
    public static void main(String[] args) {
        Circle c = new Circle(4); // Circle with radius 4
        Rectangle r = new Rectangle(4, 3); // Rectangle with height 4 and width 3

        ShowArea(c); // Display the area of the circle
        ShowArea(r); // Display the area of the rectangle
    }
    /**
     * Displays the area of the given shape.
     * @param s an object that implements the Shape interface.
     */
    public static void ShowArea(Shape s) {
        double area = s.area();
        System.out.println("The area of the shape is " + area);
    }
}