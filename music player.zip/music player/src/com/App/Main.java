package com.App;

import App.Album;
import App.Song;

import java.util.*;

public class Main {

    // List to store albums
    private static ArrayList<Album> albums = new ArrayList<>();

    public static void main(String[] args) {

        // Creating the first album and adding songs
        Album album = new Album("Album1","AC/DC");

        album.addSong("TNT",4.5);
        album.addSong("Highway to hell",3.5);
        album.addSong("ThunderStruck",5.0);
        albums.add(album);

        // Creating the second album and adding songs
        album = new Album("Album2","Eminem");

        album.addSong("Rap god",4.5);
        album.addSong("Not Afraid",3.5);
        album.addSong("Lose yourself",4.5);

        albums.add(album);

        // Creating a playlist (LinkedList) to hold selected songs
        LinkedList<Song> playList_1 = new LinkedList<>();

        // Adding songs to the playlist from different albums
        albums.get(0).addToPlayList("TNT",playList_1);
        albums.get(0).addToPlayList("Highway to hell",playList_1);
        albums.get(1).addToPlayList("Rap god",playList_1);
        albums.get(1).addToPlayList("Lose yourself",playList_1);

        // Start playing the playlist
        play(playList_1);

    }

    // Method to play songs from the playlist
    private static void play(LinkedList<Song> playList){
        Scanner sc = new Scanner(System.in);
        boolean quit = false;
        boolean forward = true;

        // ListIterator to navigate the playlist
        ListIterator<Song> listIterator = playList.listIterator();

        // If the playlist is empty, notify the user
        if(playList.size() == 0){
            System.out.println("This playlist has no song");
        } else {
            System.out.println("Now playing " + listIterator.next().toString());
            printMenu();
        }

        while(!quit){
            int action = sc.nextInt();
            sc.nextLine(); // Consume newline

            switch (action){
                case 0: // Quit playing
                    System.out.println("Playlist complete");
                    quit = true;
                    break;

                case 1: // Play next song
                    if(!forward){
                        if(listIterator.hasNext()){
                            listIterator.next();
                        }
                        forward = true;
                    }
                    if(listIterator.hasNext()){
                        System.out.println("Now playing " + listIterator.next().toString());
                    } else {
                        System.out.println("No song available, reached the end of the playlist");
                        forward = false;
                    }
                    break;

                case 2: // Play previous song
                    if(forward){
                        if (listIterator.hasPrevious()){
                            listIterator.previous();
                        }
                        forward = false;
                    }
                    if(listIterator.hasPrevious()){
                        System.out.println("Now playing " + listIterator.previous().toString());
                    } else {
                        System.out.println("This is the first song in the playlist");
                    }
                    break;

                case 3: // Replay the current song
                    if(forward){
                        if(listIterator.hasPrevious()){
                            System.out.println("Replaying " + listIterator.previous().toString());
                            forward = false;
                        } else {
                            System.out.println("At the start of the playlist");
                        }
                    } else {
                        if(listIterator.hasNext()){
                            System.out.println("Replaying " + listIterator.next().toString());
                            forward = true;
                        } else {
                            System.out.println("At the end of the playlist");
                        }
                    }
                    break;

                case 4: // Display all songs in the playlist
                    printList(playList);
                    break;

                case 5: // Display menu options
                    printMenu();
                    break;

                case 6: // Delete the current song
                    if (playList.size() > 0){
                        listIterator.remove();
                        if(listIterator.hasNext()){
                            System.out.println("Now playing " + listIterator.next().toString());
                        } else if(listIterator.hasPrevious()){
                            System.out.println("Now playing " + listIterator.previous().toString());
                        }
                    }
                    break;
            }
        }
    }

    // Display menu options for the user
    private static void printMenu(){
        System.out.println("Available options:");
        System.out.println("0 - to quit\n" +
                           "1 - to play next song\n" +
                           "2 - to play previous song\n" +
                           "3 - to replay the current song\n" +
                           "4 - list of all songs\n" +
                           "5 - print all available options\n" +
                           "6 - delete current song");
    }

    // Display all songs in the playlist
    private static void printList(LinkedList<Song> playList){
        Iterator<Song> iterator = playList.iterator();
        System.out.println("-----------------");
        while(iterator.hasNext()){
            System.out.println(iterator.next());
        }
        System.out.println("-----------------");
    }
}
