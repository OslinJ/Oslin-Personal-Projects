package App;


import java.util.ArrayList;
import java.util.LinkedList;

public class Album {
    // Album properties: name, artist, and list of songs
    private String name;
    private String artist;
    private ArrayList<Song> songs;

    // Constructor to initialize album with a name and artist
    public Album(String name, String artist) {
        this.name = name;
        this.artist = artist;
        this.songs = new ArrayList<Song>();
    }

    // Default constructor
    public Album() {
    }

    // Method to find a song by its title within the album
    public Song findSong(String title) {

        // Loop through the list of songs to find a match
        for (Song checkedSong : songs) {
            if (checkedSong.getTitle().equals(title)) return checkedSong;
        }
        // Return null if no match is found
        return null;
    }

    // Adds a song to the album if it does not already exist
    public boolean addSong(String title, double duration) {
        if (findSong(title) == null) {  // Ensure the song doesn't already exist
            songs.add(new Song(title, duration));
           System.out.println(title + " successfully added to the list");
            return true;
        } else {
           System.out.println("Song with name " + title + " already exists in the list");
            return false;
        }
    }

    // Adds a song to a playlist using its track number
    public boolean addToPlayList(int trackNumber, LinkedList<Song> PlayList) {
        int index = trackNumber - 1;  // Convert track number to a zero-based index
        // Ensure the track number is within valid range
        if (index >= 0 && index < this.songs.size()) {
            PlayList.add(this.songs.get(index));
            return true;
        }
        System.out.println("This album does not have a song with track number " + trackNumber);
        return false;
    }

    // Adds a song to a playlist using its title
    public boolean addToPlayList(String title, LinkedList<Song> PlayList) {
        // Loop through the album to find the song by title
        for (Song checkedSong : this.songs) {
            if (checkedSong.getTitle().equals(title)) {
                PlayList.add(checkedSong);
                return true;
            }
        }System.out.println(title + " - There is no such song in the album");
        return false;
    }
}
