package EmailApp;

import java.util.Scanner;

public class EmailApp{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt for first and last name
        System.out.print("Enter first name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter last name: ");
        String lastName = scanner.nextLine();

        // Create Email object
        Email employeeEmail = new Email(firstName, lastName, scanner);

        // Display generated email details
        System.out.println("\n" + employeeEmail.showInfo());

        scanner.close();
    }
}
