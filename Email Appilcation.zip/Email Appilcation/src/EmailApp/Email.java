package EmailApp;

import java.security.SecureRandom;
import java.util.Scanner;

/**
 * The Email class generates a company email and password for an employee.
 * It also allows setting an alternate email, changing the password, and managing mailbox capacity.
 */
public class Email {
    private final String firstName;
    private final String lastName;
    private String password;
    private final String department;
    private final String email;
    private int mailboxCapacity = 500;
    private String alternateEmail;
    private final String companySuffix = "aeycompany.com";
    private static final int DEFAULT_PASSWORD_LENGTH = 10;
    private static final String PASSWORD_SET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890!@$-";

    public Email(String firstName, String lastName, Scanner scanner) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.department = setDepartment(scanner);
        this.password = generateRandomPassword(DEFAULT_PASSWORD_LENGTH);
        System.out.println("Generated Password: " + this.password);
        this.email = generateEmail();
    }
    private String setDepartment(Scanner scanner) {
        int depChoice;
        while (true) {
            System.out.println("Department Codes:");
            System.out.println("1 - Sales\n2 - Development\n3 - Accounting\nEnter department code:");

            if (scanner.hasNextInt()) {
                depChoice = scanner.nextInt();
                if (depChoice >= 1 && depChoice <= 3) break;
            } else {
                scanner.next(); // Consume invalid input
            }
            System.out.println("Invalid choice. Please enter 1, 2, or 3.");
        }

        return switch (depChoice) {
            case 1 -> "Sales";
            case 2 -> "Development";
            case 3 -> "Accounting";
            default -> "";
        };
    }

    /**
     * Generates a random password of the specified length.
     *
     * @param length Length of the generated password.
     * @return Randomly generated password.
     */
    private String generateRandomPassword(int length) {
        SecureRandom random = new SecureRandom();
        char[] password = new char[length];
        for (int i = 0; i < length; i++) {
            password[i] = PASSWORD_SET.charAt(random.nextInt(PASSWORD_SET.length()));
        }
        return new String(password);
    }

    /**
     * @return Formatted email as a string.
     */
    private String generateEmail() {
        return String.format("%s.%s@%s.%s",
                firstName.toLowerCase(),
                lastName.toLowerCase(),
                department.toLowerCase(),
                companySuffix);
    }

    /**
     * @param capacity New mailbox capacity in MB.
     */
    public void setMailboxCapacity(int capacity) {
        this.mailboxCapacity = capacity;
    }

    /**
     * @param altEmail The alternate email address.
     */
    public void setAlternateEmail(String altEmail) {
        this.alternateEmail = altEmail;
    }

    /**
     * Changes the user's password.
     *
     * @param password New password.
     */
    public void changePassword(String password) {
        this.password = password;
    }

    /**
     * @return Mailbox capacity in MB.
     */
    public int getMailboxCapacity() {
        return mailboxCapacity;
    }

    /**
     * @return Alternate email address as a string.
     */
    public String getAlternateEmail() {
        return alternateEmail;
    }

    /**
     * @return Current password as a string.
     */
    public String getPassword() {
        return password;
    }

    /**
     * @return Employee details as a formatted string.
     */
    public String showInfo() {
        return String.format("Display Name: %s %s%nCompany Email: %s%nMailbox Capacity: %dMB",
                firstName, lastName, email, mailboxCapacity);
    }
}
