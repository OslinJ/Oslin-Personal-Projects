public enum Selection {
    ROCK, PAPER, SCISSORS
}
