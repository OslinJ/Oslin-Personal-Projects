import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class Main {
    static Scanner scan = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Lets play a game of Rock, Paper, Scissors");

        while (true) {
            int userChoice = getUserChoice();
            if (userChoice == -1) {
                continue;
            }
            int cpuChoice = getCpuChoice();

            System.out.println("User picked: " + Selection.values()[userChoice - 1]);
            System.out.println("CPU picked: " + Selection.values()[cpuChoice - 1]);

            determineWinner(userChoice, cpuChoice);

            System.out.println("Do you want to play again? (Y/N)");
            String playAgain = scan.next().trim().toLowerCase();
            if (!playAgain.equals("y")) {
                System.out.println("Thanks for playing! Goodbye.");
                break;
            }
        }
    }

    public static int getUserChoice() {
        System.out.println("Press (1) - Rock, (2) - Paper, (3) - Scissor");
        try {
            int userChoice = scan.nextInt();
            if (userChoice < 1 || userChoice > 3) {
                System.out.println("Invalid user choice.");
                return -1;
            }
            return userChoice;
        } catch (InputMismatchException ime) {
            System.out.println("Selection must be an integer");
            scan.next();
            return -1;
        }
    }

    public static int getCpuChoice() {
        Random ran = new Random();
        return ran.nextInt(3) + 1;
    }

    public static void determineWinner(int userChoice, int cpuChoice) {
        if(userChoice == cpuChoice){
            System.out.println("It is a tie !!!");
        }
        else if( (userChoice == 1 && cpuChoice == 3)
            || (userChoice == 2 && cpuChoice == 1)
            || (userChoice == 3 && cpuChoice == 2)){
            System.out.println("Player wins !");
        }
        else{
            System.out.println("Cpu wins !");
        }
    }
}
