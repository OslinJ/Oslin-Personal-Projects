public class Main {
    public static void main(String[] args) {
        Suv Lexus = new Suv("Lexus", false);
        Lexus.move(40, 0);
        Lexus.accelerate(10);
        System.out.println(Lexus);


    }
}