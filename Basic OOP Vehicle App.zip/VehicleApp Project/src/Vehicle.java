public class Vehicle {
    private String name;
    private int currentSpeed;
    private int currentDirection;
    public Vehicle(String name) {
        this.name = name;
        this.currentSpeed = 0;
        this.currentDirection = 0;
    }
    public void steer(int direction){
        this.currentDirection += direction;
        System.out.println("Steer method called: Steering at " + currentDirection + " degrees.");
    }
    public void move(int speed, int direction){
        setCurrentSpeed(speed);
        setCurrentDirection(direction);
        System.out.println("move method called: Moving at " + getCurrentSpeed() + " in direction " + getCurrentDirection());
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getCurrentSpeed() {
        return currentSpeed;
    }
    public int getCurrentDirection() {
        return currentDirection;
    }
    public void setCurrentSpeed(int speed) {
        currentSpeed = speed;
    }
    public void setCurrentDirection(int direction) {
        currentDirection = direction;
    }
    public void stop(){
        this.currentSpeed = 0;
        System.out.println("Vehicle has stopped");
    }
    @Override
    public String toString(){
        return "Vehicle name: " + getName() + " \ncurrentSpeed: " + getCurrentSpeed() + " \ncurrentDirection: " + getCurrentDirection();

    }



}
