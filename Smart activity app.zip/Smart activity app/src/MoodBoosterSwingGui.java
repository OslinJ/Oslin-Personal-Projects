import javax.swing.*;
import java.awt.*;

public class MoodBoosterSwingGui {
    public static void main(String[] args) {
        // Create the main window (JFrame)
        JFrame frame = new JFrame("Mood Booster App");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Create input panel (top)
        JPanel inputPanel = new JPanel();
        JTextField cityField = new JTextField(20);
        JButton fetchButton = new JButton("Get Weather & Joke");
        inputPanel.add(new JLabel("Enter city:"));
        inputPanel.add(cityField);
        inputPanel.add(fetchButton);

        // Create output panel (center)
        JTextArea outputArea = new JTextArea();
        outputArea.setEditable(false);
        outputArea.setLineWrap(true);
        outputArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(outputArea);

        // Add panels to frame
        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);

        // Handle button click
        fetchButton.addActionListener(e -> {
            String city = cityField.getText().trim();
            if (city.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please enter a city.", "Input Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try {
                Weather weather = WeatherService.getWeather(city);
                String joke = JokeService.getJoke();

                String weatherReport = "🌤️ Weather in " + city + ":\n" + weather.toString() + "\n\n";
                String jokeReport = "😂 Joke:\n" + joke;

                outputArea.setText(weatherReport + jokeReport);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage(), "API Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Make the window visible
        frame.setVisible(true);
    }
}
