import com.google.gson.Gson;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class JokeService {

    static class JokeResponse{
        String type;
        String joke;
        String setup;
        String delivery;
    }
    public static String getJoke() throws Exception {
        HttpClient client = HttpClient.newHttpClient();

        String endpoint = "https://v2.jokeapi.dev/joke/Any?format=json&type=any";
        HttpRequest request = HttpRequest.newBuilder()
                .uri(new URI(endpoint))
                .GET()
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        String json = response.body();
        Gson gson = new Gson();
        JokeResponse jokeResponse = gson.fromJson(json, JokeResponse.class);

        if("single".equals(jokeResponse.type)){
            return jokeResponse.joke;
        }
        else{
            return jokeResponse.setup + "\n" + jokeResponse.delivery;
        }
    }
}
