public class Joke {
    private String joke;
    private String category;
    private String type;

    public String getJoke() {
        return joke;
    }
    public void setJoke(String joke) {
        this.joke = joke;
    }
    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    @Override
    public String toString(){
        return "Category: " + getCategory() + "\nType: " + getType() + "\nJoke: " + getJoke();
    }

}
