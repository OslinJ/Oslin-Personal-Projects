public class viewBalance {
    int total;

    public static void balance(){


    }

}
