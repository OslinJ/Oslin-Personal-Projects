import java.util.InputMismatchException;
import java.util.Scanner;

public class ATM {

    static Scanner scan = new Scanner(System.in);
    public double balance = 0;

    public static void main(String[] args) {
        ATM atm = new ATM();
        atm.authenticateUser();
        atm.displayMainMenu();
    }

    public void displayMainMenu() {
        int option;
        while (true) {
            System.out.println("Main menu - select an option");
            System.out.println("1. View Balance");
            System.out.println("2. Withdraw");
            System.out.println("3. Deposit");
            System.out.println("4. Exit");

            try {
                option = scan.nextInt();
                if (option == 1) {
                    System.out.println("Your current balance is: " + balance);
                } else if (option == 2) {
                    Withdraw.withdrawAmount(scan, this); // Pass the ATM instance
                } else if (option == 3) {
                    Deposit.depositAmount(scan, this); // Pass the ATM instance
                } else if (option == 4) {
                    System.out.println("Exiting the ATM system");
                    System.exit(0); // Exit the program
                } else {
                    System.out.println("Invalid option. Please select a valid option.");
                }
            } catch (InputMismatchException ime) {
                System.out.println("Please enter a valid option");
                scan.nextLine(); // Clear the invalid input
            }
        }
    }
    public void authenticateUser() {
        String pin = "";
        while(true){
            System.out.println("Please enter the 4 digit pin number to access the ATM");
            try {
                pin = scan.nextLine();
                int pinNum = Integer.parseInt(pin);
            }
            catch (NumberFormatException nfe) {
                System.out.println("Please enter a integer to authenticate your pin");
                continue;
            }
            if (pin.length() > 4) {
                System.out.println("The pin number is greater than 4 digits");
            }
            else if (pin.length() < 4) {
                System.out.println("The pin number is less than 4 digits");
            }
            else {
                System.out.println("User Authenticated");
                break;
            }
        }
    }
}
