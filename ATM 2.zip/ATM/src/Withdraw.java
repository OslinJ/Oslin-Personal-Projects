import java.util.InputMismatchException;
import java.util.Scanner;

public class Withdraw {

    public static void withdrawAmount(Scanner scan, ATM atm) {
        int withdrawal;  // Default to -1 indicating no valid withdrawal

        while (true) {
            System.out.println("How much money would you like to withdraw?");

            try {
                withdrawal = scan.nextInt();  // Get user input
                scan.nextLine();  // Clear the buffer

                // Check if the withdrawal amount is valid
                if (withdrawal <= 0) {
                    System.out.println("Withdrawal amount cannot be less than or equal to $0.");
                } else if (withdrawal > 1000) {
                    System.out.println("Withdrawal cannot be greater than $1000.");
                } else if (withdrawal <= atm.balance) {
                    atm.balance -= withdrawal;  // Update ATM balance
                    System.out.println("You've successfully withdrawn $" + withdrawal);
                    break;  // Exit loop after successful withdrawal
                } else {
                    System.out.println("Try again, Insufficient funds");
                    return;
                }

            } catch (InputMismatchException ime) {
                System.out.println("Please input a valid integer for the withdrawal.");
                scan.nextLine();  // Clear invalid input
            }

            // Ask the user if they want to make another withdrawal
        }
    }
}
