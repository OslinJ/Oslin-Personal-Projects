import java.util.InputMismatchException;
import java.util.Scanner;

public class Deposit {

    public static void depositAmount(Scanner scan, ATM atm) {
        double deposit;
        while (true) {
            System.out.println("How much money would you like to deposit?");
            try {
                deposit = scan.nextDouble();  // Get deposit input
                scan.nextLine();  // Consume the newline character left by nextInt()

                // Validate deposit input
                if (deposit <= 0) {
                    System.out.println("Deposit cannot be less than or equal to $0.");
                } else if (deposit > 2000) {
                    System.out.println("Deposit cannot be greater than $2000.");
                } else {
                    // Successful deposit, update balance
                    atm.balance += deposit;
                    System.out.println("You've deposited $" + deposit);
                    System.out.println("Your new balance is: $" + atm.balance);
                }

            } catch (InputMismatchException ime) {
                System.out.println("Please input a valid integer for the deposit.");
                scan.nextLine();  // Clear invalid input from the buffer
                continue; // Ask for input again
            }

            // Ask user if they want to perform another deposit
            System.out.println("Would you like to perform another deposit (Y/N)?");
            String choice = scan.nextLine().trim();  // Trim spaces from the input

            if (choice.equalsIgnoreCase("N")) {
                atm.displayMainMenu();
                break; // Exit the loop after displaying the main menu
            } else if (!choice.equalsIgnoreCase("Y")) {
                System.out.println("Invalid choice. Exiting deposit process.");
                return; // Exit if the input is neither "Y" nor "N"
            }
        }

    }
}
