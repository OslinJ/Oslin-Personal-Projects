public class Main {
    public static void main(String[] args) {
        // Example usage
        HashTable hashTable = new HashTable(10);
        hashTable.insert(15);
        hashTable.insert(25);
        hashTable.insert(35);
        hashTable.displayTable();

        Node root = new Node(50);
        root.insert(30);
        root.insert(70);
        root.insert(20);
        root.insert(40);
        root.insert(60);
        root.insert(80);

        System.out.println("\nIn-Order Traversal:");
        root.inOrder(root);
    }

    // Hash Table Implementation with Collision Resolution
    static class HashTable {
        private int size;
        private Integer[] table;

        public HashTable(int size) {
            this.size = size;
            table = new Integer[size];
        }

        // Insert key using linear probing
        public int insert(int key) {
            int index = key % size;
            int startIndex = index;

            while (table[index] != null) {
                if (table[index].equals(key)) {
                    return index; // Key already exists
                }
                index = (index + 1) % size;
                if (index == startIndex) {
                    return -1; // Table is full
                }
            }
            table[index] = key;
            return index;
        }

        // Linear probing search
        public int getLinearProbeIndex(int key) {
            int index = key % size;
            int startIndex = index;

            while (table[index] != null) {
                if (table[index].equals(key)) {
                    return index;
                }
                index = (index + 1) % size;
                if (index == startIndex) {
                    return -1;
                }
            }
            return -1;
        }

        // Quadratic probing search
        public int getQuadraticProbeIndex(int key) {
            int index = key % size;
            int originalIndex = index;
            int i = 1;

            while (table[index] != null) {
                if (table[index].equals(key)) {
                    return index;
                }
                index = (originalIndex + i * i) % size;
                i++;
                if (i >= size) {
                    return -1;
                }
            }
            return -1;
        }

        // Double hashing search
        public int getDoubleHash(int key) {
            int hash1 = key % size;
            int hash2 = 1 + (key % (size - 1));
            int index = hash1;
            int i = 0;

            while (table[index] != null) {
                if (table[index].equals(key)) {
                    return index;
                }
                index = (hash1 + i * hash2) % size;
                i++;
                if (i >= size) {
                    return -1;
                }
            }
            return -1;
        }

        // Search key using specified probing method
        public void searchHash(int key, String probeMethod) {
            int index;
            switch (probeMethod.toLowerCase()) {
                case "linear":
                    index = getLinearProbeIndex(key);
                    break;
                case "quadratic":
                    index = getQuadraticProbeIndex(key);
                    break;
                case "double":
                    index = getDoubleHash(key);
                    break;
                default:
                    System.out.println("Invalid probe method");
                    return;
            }
            System.out.println(index != -1 ? "Key " + key + " found at index " + index : "Key " + key + " not found");
        }

        // Display hash table
        public void displayTable() {
            for (int i = 0; i < size; i++) {
                System.out.println("Index " + i + ": " + (table[i] == null ? "Empty" : table[i]));
            }
        }
    }

    // Binary Search Tree (BST) Implementation
    static class Node {
        int data;
        Node left, right;

        public Node(int data) {
            this.data = data;
            this.left = this.right = null;
        }

        // Insert a node into BST
        public void insert(int value) {
            if (value < data) {
                if (left == null) {
                    left = new Node(value);
                } else {
                    left.insert(value);
                }
            } else {
                if (right == null) {
                    right = new Node(value);
                } else {
                    right.insert(value);
                }
            }
        }

        // Find the minimum value node
        public Node treeMin(Node x) {
            while (x.left != null) {
                x = x.left;
            }
            return x;
        }

        // Find the maximum value node
        public Node treeMax(Node x) {
            while (x.right != null) {
                x = x.right;
            }
            return x;
        }

        // In-Order Traversal (Left, Root, Right)
        public void inOrder(Node x) {
            if (x != null) {
                inOrder(x.left);
                System.out.print(x.data + " ");
                inOrder(x.right);
            }
        }

        // Pre-Order Traversal (Root, Left, Right)
        public void preOrder(Node x) {
            if (x != null) {
                System.out.print(x.data + " ");
                preOrder(x.left);
                preOrder(x.right);
            }
        }

        // Post-Order Traversal (Left, Right, Root)
        public void postOrder(Node x) {
            if (x != null) {
                postOrder(x.left);
                postOrder(x.right);
                System.out.print(x.data + " ");
            }
        }

        // Search in BST
        public int searchBST(Node x, int target) {
            if (x == null) {
                return -1; // Not found
            }
            if (x.data == target) {
                return target;
            }
            return (target < x.data) ? searchBST(x.left, target) : searchBST(x.right, target);
        }
    }
}
