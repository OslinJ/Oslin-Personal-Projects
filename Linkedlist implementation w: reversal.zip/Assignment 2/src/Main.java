import linkedList.LinkedList;

public class Main {
    public static void main(String[] args) {
            LinkedList<Integer> list = new LinkedList<>();

            list.addFirst(50);
            list.addFirst(40);
            list.addFirst(90);
            list.addFirst(80);
            list.addFirst(70);
            list.addFirst(60);

        System.out.println(list);
        list.reverse();
        System.out.println(list);


    }
}