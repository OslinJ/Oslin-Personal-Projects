import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Main class that demonstrates sorting, linear search, and binary search on a dynamically created array.
 */
public class Main {
    static int[] n;

    /**
     * Prompts the user for array size, fills the array with random integers, sorts it,
     * and performs linear and binary search on a target value provided by the user.
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        System.out.println("How many elements would you like in your array?");
        try {
            n = new int[scan.nextInt()];
        } catch (InputMismatchException ime) {
            System.out.println("Please input an integer...");
            return;
        }

        System.out.println("Great! You selected " + n.length + " elements.");
        fillArray(n);

        System.out.println("Array filled and sorted:");
        for (int i : n) {
            System.out.print(i + " ");
        }
        System.out.println();

        int target = 0;
        System.out.println("Enter the target value to search:");
        try {
            target = scan.nextInt();
        } catch (InputMismatchException ime) {
            System.out.println("Please input an integer...");
            return;
        }

        // Perform linear search
        long startTime = System.nanoTime();
        int linearResult = linearSearch(n, target, 0);
        long endTime = System.nanoTime();
        long elapsedTime = endTime - startTime;

        if (linearResult != -1) {
            System.out.println("Linear search found " + target + " at index " + linearResult + " in (" + elapsedTime + " ns).");
        } else {
            System.out.println("Linear search did not find " + target + ".");
        }

        // Perform binary search
        startTime = System.nanoTime();
        int binaryResult = binarySearch(n, target, 0, n.length - 1);
        endTime = System.nanoTime();
        elapsedTime = endTime - startTime;

        if (binaryResult != -1) {
            System.out.println("Binary search found " + target + " at index " + binaryResult + " in (" + elapsedTime + " ns).");
        } else {
            System.out.println("Binary search did not find " + target + ".");
        }

        scan.close();
    }

    /**
     * Sorts the array using the Selection Sort algorithm.
     *
     * @param arr the array to sort
     */
    private static void selectionSort(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            int min = i;
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[j] < arr[min]) {
                    min = j;
                }
            }
            int temp = arr[i];
            arr[i] = arr[min];
            arr[min] = temp;
        }
    }

    /**
     * Performs a recursive linear search on the array.
     *
     * @param arr    the array to search
     * @param target the value to search for
     * @param index  the current index in the array
     * @return the index of the target if found, otherwise -1
     */
    private static int linearSearch(int[] arr, int target, int index) {
        if (index == arr.length) return -1;
        if (arr[index] == target) return index;
        return linearSearch(arr, target, index + 1);
    }

    /**
     * Performs a recursive binary search on the array.
     * Assumes the array is already sorted in ascending order.
     *
     * @param arr    the array to search
     * @param target the value to search for
     * @param start  the starting index of the search range
     * @param end    the ending index of the search range
     * @return the index of the target if found, otherwise -1
     */
    private static int binarySearch(int[] arr, int target, int start, int end) {
        if (start > end) return -1;
        int mid = start + (end - start) / 2;
        if (arr[mid] == target) return mid;
        else if (arr[mid] > target) return binarySearch(arr, target, start, mid - 1);
        return binarySearch(arr, target, mid + 1, end);
    }

    /**
     * Fills the array with random integers and sorts it.
     *
     * @param arr the array to fill
     */
    private static void fillArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            arr[i] = (int) (Math.random() * 100000);
        }
        selectionSort(arr);
    }
}
