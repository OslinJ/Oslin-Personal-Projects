import java.util.ArrayList;
import java.util.List;

/**
 * Represents a CarMax inventory system that manages a list of cars.
 */
public class CarMax {
    private List<Car> cars;

    /**
     * Constructs an empty CarMax inventory.
     */
    public CarMax() {
        cars = new ArrayList<>();
    }

    /**
     * Adds a car to the inventory with the specified make and model.
     *
     * @param make the make of the car
     * @param model the model of the car
     */
    public void addCars(String make, String model) {
        Car newCar = new Car(model, make);
        cars.add(newCar);
        System.out.println("Vehicle added to inventory: " + make + " " + model);
    }

    /**
     * Removes a car from the inventory by its index, if valid.
     *
     * @param carId the index of the car to remove
     */
    public void removeCar(int carId) {
        if (carId >= 0 && carId < cars.size()) {
            System.out.println("Vehicle removed from inventory: " + cars.get(carId).getMake() + " " + cars.get(carId).getModel());
            cars.remove(carId);
        } else {
            System.out.println("Vehicle isn't in the inventory");
        }
    }

    /**
     * Displays the inventory of cars with their details.
     */
    public void displayInventory() {
        System.out.println("-------- Inventory --------");
        for (int i = 0; i < cars.size(); i++) {
            System.out.println(i + ": " + cars.get(i));
        }
    }

    /**
     * Marks a car as purchased by its index, if valid.
     *
     * @param carId the index of the car to mark as purchased
     */
    public void markAsPurchased(int carId) {
        if (carId >= 0 && carId < cars.size()) {
            cars.get(carId).isPurchased();
            System.out.println("Vehicle marked as purchased: " + cars.get(carId).getMake() + " " + cars.get(carId).getModel());
        } else {
            System.out.println("Vehicle isn't in the inventory");
        }
    }
}