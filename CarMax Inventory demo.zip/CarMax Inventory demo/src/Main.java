/**
 * The Main class to test the CarMax inventory management system.
 */
public class Main {
    /**
     * Main method to add cars to inventory, mark some as purchased, and display inventory.
     */
    public static void main(String[] args) {
        CarMax car = new CarMax();

        car.addCars("Ford", "Mustang");
        car.addCars("Toyota", "Camry");
        car.addCars("Tesla", "Model 3");
        car.addCars("Chevy", "Camaro");

        car.markAsPurchased(0);
        car.displayInventory();
    }
}