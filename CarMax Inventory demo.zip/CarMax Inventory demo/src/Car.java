/**
 * Represents a Car with a model, make, and purchase status.
 */
public class Car {
    private String model;
    private String make;
    private boolean isPurchased;

    /**
     * Constructs a Car object with the specified model and make.
     * Initially, the car is not purchased.
     *
     * @param model the model of the car
     * @param make the make of the car
     */
    public Car(String model, String make) {
        this.model = model;
        this.make = make;
        this.isPurchased = false;
    }

    /**
     * Gets the model of the car.
     *
     * @return the model of the car
     */
    public String getModel() {
        return model;
    }

    /**
     * Sets the model of the car, ensuring it is not null or empty.
     *
     * @param model the new model of the car
     */
    public void setModel(String model) {
        if (model == null || model.isEmpty()) {
            System.out.println("Model cannot be empty or null");
        }
        this.model = model;
    }

    /**
     * Gets the make of the car.
     *
     * @return the make of the car
     */
    public String getMake() {
        return make;
    }

    /**
     * Sets the make of the car, ensuring it is not null or empty.
     *
     * @param make the new make of the car
     */
    public void setMake(String make) {
        if (make == null || make.isEmpty()) {
            System.out.println("Make cannot be empty or null");
        }
        this.make = make;
    }

    /**
     * Sets the purchase status of the car.
     *
     * @param isPurchased true if the car is purchased, false otherwise
     */
    public void setPurchased(boolean isPurchased) {
        this.isPurchased = isPurchased;
    }

    /**
     * Gets the purchase status of the car.
     *
     * @return true if the car is purchased, false otherwise
     */
    public boolean isPurchased() {
        return isPurchased = true;
    }

    /**
     * Returns a string representation of the car, indicating if it's purchased or for sale.
     *
     * @return a string describing the car's make, model, and purchase status
     */
    @Override
    public String toString() {
        return (isPurchased ? "[Purchased] " : "[For Sale] ") + getMake() + " " + getModel();
    }
}