package screens;

import constants.CommonConstants;
import database.Answer;
import database.Category;
import database.JDBC;
import database.Question;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class QuizScreenGui extends JFrame implements ActionListener {
    private JLabel scoreLabel;
    private JTextArea questionTextArea;
    private JButton[] answerButtons;
    private JButton nextButton;

    private Category category;
    private ArrayList<Question> questions;
    private Question currentQuestion;
    private int currentQuestionNumber = 0;
    private int numOfQuestions;
    private int score = 0;
    private boolean firstChoiceMade = false;

    public QuizScreenGui(Category category, int numOfQuestions) {
        super("Quiz Game");
        setSize(400, 565);
        setLayout(null);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(CommonConstants.LIGHT_BLUE);

        this.category = category;
        answerButtons = new JButton[4];

        // Load questions from database
        questions = JDBC.getQuestions(category);

        if (questions == null || questions.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No questions available for this category.");
            dispose();
            return;
        }

        this.numOfQuestions = Math.min(numOfQuestions, questions.size());

        for (Question question : questions) {
            ArrayList<Answer> answers = JDBC.getAnswers(question);
            if (answers != null) {
                question.setAnswers(answers);
            } else {
                question.setAnswers(new ArrayList<>());
            }
        }

        currentQuestion = questions.get(currentQuestionNumber);
        addGuiComponents();
    }

    private void addGuiComponents() {
        JLabel topicLabel = new JLabel("Topic: " + category.getCategoryName());
        topicLabel.setFont(new Font("Arial", Font.BOLD, 16));
        topicLabel.setBounds(15, 15, 250, 20);
        topicLabel.setForeground(CommonConstants.BRIGHT_YELLOW);
        add(topicLabel);

        scoreLabel = new JLabel("Score: " + score + "/" + numOfQuestions);
        scoreLabel.setFont(new Font("Arial", Font.BOLD, 16));
        scoreLabel.setBounds(270, 15, 120, 20);
        scoreLabel.setForeground(CommonConstants.BRIGHT_YELLOW);
        add(scoreLabel);

        questionTextArea = new JTextArea(currentQuestion.getQuestionText());
        questionTextArea.setFont(new Font("Arial", Font.BOLD, 24));
        questionTextArea.setBounds(15, 50, 350, 80);
        questionTextArea.setLineWrap(true);
        questionTextArea.setWrapStyleWord(true);
        questionTextArea.setEditable(false);
        questionTextArea.setForeground(CommonConstants.BRIGHT_YELLOW);
        questionTextArea.setBackground(CommonConstants.LIGHT_BLUE);
        add(questionTextArea);

        addAnswerComponents();

        JButton returnToTitleButton = new JButton("Return to Title");
        returnToTitleButton.setFont(new Font("Arial", Font.BOLD, 16));
        returnToTitleButton.setBounds(60, 420, 262, 35);
        returnToTitleButton.setBackground(CommonConstants.BRIGHT_YELLOW);
        returnToTitleButton.setForeground(CommonConstants.LIGHT_BLUE);
        returnToTitleButton.addActionListener(e -> {
            TitleScreenGui titleScreenGui = new TitleScreenGui();
            titleScreenGui.setLocationRelativeTo(QuizScreenGui.this);
            dispose();
            titleScreenGui.setVisible(true);
        });
        add(returnToTitleButton);

        nextButton = new JButton("Next");
        nextButton.setFont(new Font("Arial", Font.BOLD, 16));
        nextButton.setBounds(240, 470, 80, 35);
        nextButton.setBackground(CommonConstants.BRIGHT_YELLOW);
        nextButton.setForeground(CommonConstants.LIGHT_BLUE);
        nextButton.setVisible(false);
        nextButton.addActionListener(e -> loadNextQuestion());
        add(nextButton);
    }

    private void addAnswerComponents() {
        int verticalSpacing = 60;

        for (int i = 0; i < answerButtons.length; i++) {
            answerButtons[i] = new JButton();
            answerButtons[i].setBounds(60, 180 + (i * verticalSpacing), 262, 45);
            answerButtons[i].setFont(new Font("Arial", Font.BOLD, 18));
            answerButtons[i].setHorizontalAlignment(SwingConstants.LEFT);
            answerButtons[i].setBackground(Color.WHITE);
            answerButtons[i].setForeground(CommonConstants.DARK_BLUE);
            answerButtons[i].addActionListener(this);
            add(answerButtons[i]);
        }

        updateAnswerButtons();
    }

    private void updateAnswerButtons() {
        ArrayList<Answer> answers = currentQuestion.getAnswers();
        for (int i = 0; i < answerButtons.length; i++) {
            if (i < answers.size()) {
                answerButtons[i].setText(answers.get(i).getAnswerText());
                answerButtons[i].setVisible(true);
            } else {
                answerButtons[i].setVisible(false);
            }
        }
    }

    private void loadNextQuestion() {
        if (++currentQuestionNumber >= numOfQuestions) {
            JOptionPane.showMessageDialog(this, "Final Score: " + score + "/" + numOfQuestions);
            dispose();
            return;
        }

        currentQuestion = questions.get(currentQuestionNumber);
        questionTextArea.setText(currentQuestion.getQuestionText());
        firstChoiceMade = false;

        for (JButton answerButton : answerButtons) {
            answerButton.setBackground(Color.WHITE);
        }

        updateAnswerButtons();
        nextButton.setVisible(false);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton answerButton = (JButton) e.getSource();

        Answer correctAnswer = currentQuestion.getAnswers().stream()
                .filter(Answer::isCorrect)
                .findFirst()
                .orElse(null);

        if (correctAnswer == null) return;

        if (answerButton.getText().equals(correctAnswer.getAnswerText())) {
            answerButton.setBackground(CommonConstants.LIGHT_GREEN);
            if (!firstChoiceMade) {
                scoreLabel.setText("Score: " + (++score) + "/" + numOfQuestions);
            }
            if (currentQuestionNumber == numOfQuestions - 1) {
                JOptionPane.showMessageDialog(this, "Final Score: " + score + "/" + numOfQuestions);
                dispose();
            } else {
                nextButton.setVisible(true);
            }
        } else {
            answerButton.setBackground(CommonConstants.LIGHT_RED);
        }

        firstChoiceMade = true;
    }
}
